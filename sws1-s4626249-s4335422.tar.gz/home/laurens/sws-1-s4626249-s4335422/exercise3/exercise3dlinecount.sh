i=1
echo -n > exercise3d.txt #empty exercise3d.txt
while [ "$i" -le 10 ]
do
    ./exercise3d > exercise3doutput.txt #run the executable made from exercise3d.c
    linecount=$(wc -l < exercise3doutput.txt)#count the number of line
    echo $linecount >> exercise3d.txt #append the number of lines to exercise3d.txt
    i=$(( i + 1 ))
done
