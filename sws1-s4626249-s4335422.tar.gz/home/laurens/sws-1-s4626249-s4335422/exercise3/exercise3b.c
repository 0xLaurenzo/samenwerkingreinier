#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdio.h>
#include <unistd.h>

int main(){
  int signedrand = 0;
  unsigned int unsrand = 0;
  int randdata = open("/dev/urandom", O_RDONLY); // open /dev/urandom  
  while (signedrand != 42){
    read(randdata, &signedrand, 1); // read a rand int
    unsrand = (unsigned int)signedrand; // make this int unsigned
    printf("%d %d %x \n", signedrand, unsrand, unsrand); // output in the correct order
  }
}
