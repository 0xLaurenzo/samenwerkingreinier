#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdio.h>
#include <unistd.h>
#include <stdint.h>

int main(){
  uint16_t  unsrand = 0;
  int randdata = open("/dev/urandom", O_RDONLY); // open /dev/urandom
  while (unsrand != 42){
    read(randdata, &unsrand, sizeof unsrand); // read a rand int
    printf("%04x\n",unsrand); // output in the correct order
  }
}
